'use strict';
// ===== کھلاڑی، ہتھیار، گولیاں، زون =====
function mkEnt(x, y, isPlayer, name, idx) {
  return {
    x, y, r: 14, hp: 100, armor: 0, ang: R() * TAU, vx: 0, vy: 0, mx: 0, my: 0, fire: false,
    slots: [null, null], cur: 0, ammo: { l: 0, h: 0, s: 0 }, hitT: -99, aggr: .15 + R() * .65, engage: true,
    gren: 0, med: 0, band: 0, fireCd: 0, reloadT: 0, healT: 0, healKind: '', flash: 0,
    alive: true, kills: 0, name, isPlayer, idx, hue: isPlayer ? 175 : (R() * 70 + 340) % 360,
    // بوٹ کی حالت
    thinkT: R() * .3, mode: 'roam', goal: null, goalT: 0, enemy: null, react: 0, strafe: 1, strafeT: 0,
    sx: x, sy: y, sT: 0, unT: 0, us: 1, nav: null, zg: null, zgPh: -2, dmgDone: 0
  };
}
function addLoot(x, y, t, n) { G.loot.push({ x, y, t, n: n || 0 }); }
function lootAmount(t) {
  if (WEAP[t]) return WEAP[t].mag;
  if (t === 'ammo_l') return 30; if (t === 'ammo_h') return 30; if (t === 'ammo_s') return 10;
  return 1;
}
function fx(type, x, y, extra) { if (G.fx.length < 220) G.fx.push(Object.assign({ type, x, y, t: 0 }, extra || {})); }
function ftext(x, y, s, col) { if (G.texts.length < 40) G.texts.push({ x, y, s, col, t: 0 }); }
function say(s) { G.msg = s; G.msgT = 2.4; }
function feed(s) { G.feed.push({ s, t: 7 }); if (G.feed.length > 5) G.feed.shift(); }

// ----- شروع -----
function spawnPoint() {
  for (let i = 0; i < 300; i++) {
    const x = rnd(220, W - 220), y = rnd(220, H - 220);
    if (Math.hypot(x - W / 2, y - H / 2) > 2600) continue;
    if (inB(x, y, 20) || blockedPt(x, y, 30)) continue;
    let ok = true; for (const e of G.ents) if (Math.hypot(e.x - x, e.y - y) < 380) { ok = false; break; }
    if (ok) return [x, y];
  }
  return [rnd(300, W - 300), rnd(300, H - 300)];
}
function newGame(name, diff) {
  genMap();
  G = { running: true, paused: false, over: false, t: 0, diff, ents: [], loot: [], bullets: [], grens: [], fx: [], texts: [],
        feed: [], msg: '', msgT: 0, shake: 0, deadT: 0, endShown: false, player: null, dmgFlash: 0, zoneWarn: 0 };
  const names = BOT_NAMES.slice().sort(() => R() - .5);
  const [px, py] = spawnPoint();
  const p = mkEnt(px, py, true, name || 'آپ', 0); G.ents.push(p); G.player = p;
  for (let i = 0; i < 29; i++) { const [x, y] = spawnPoint(); G.ents.push(mkEnt(x, y, false, names[i], i + 1)); }
  // ہر کھلاڑی کے قریب شروعاتی ہتھیار اور گولیاں
  for (const e of G.ents) {
    const w = pick(['pistol', 'pistol', 'smg', 'shotgun']);
    for (const t of [w, 'ammo_' + WEAP[w].ammo]) {
      for (let k = 0; k < 30; k++) {
        const a = R() * TAU, d = rnd(60, 130), x = e.x + Math.cos(a) * d, y = e.y + Math.sin(a) * d;
        if (x < 40 || y < 40 || x > W - 40 || y > H - 40 || blockedPt(x, y, 16) || inB(x, y, 10)) continue;
        addLoot(x, y, t, lootAmount(t)); break;
      }
    }
  }
  // لوٹ: عمارتوں میں اور باہر
  for (const b of buildings) {
    const n = 4 + ((R() * 3) | 0);
    for (let i = 0; i < n; i++) {
      for (let k = 0; k < 12; k++) {
        const x = rnd(b.x + T + 22, b.x + b.w - T - 22), y = rnd(b.y + T + 22, b.y + b.h - T - 22);
        if (blockedPt(x, y, 14)) continue;
        const t = randLootType(); addLoot(x, y, t, lootAmount(t)); break;
      }
    }
  }
  for (let i = 0; i < 150; i++) {
    const x = rnd(120, W - 120), y = rnd(120, H - 120);
    if (inB(x, y, 10) || blockedPt(x, y, 16)) continue;
    let t = randLootType(); if (t === 'sniper' && R() < .6) t = 'ammo_h';
    addLoot(x, y, t, lootAmount(t));
  }
  G.zone = { x: W / 2, y: H / 2, r: 2900, fx: 0, fy: 0, fr: 0, tx: 0, ty: 0, tr: 0, phase: -1, state: 'wait', t: 0, dps: 0.5, final: false };
  nextPhase();
  say('کھیل شروع! ہتھیار ڈھونڈیں');
}
function nextPhase() {
  const z = G.zone; z.phase++;
  if (z.phase >= ZP.length) { z.final = true; z.state = 'final'; return; }
  const p = ZP[z.phase];
  const a = R() * TAU, d = R() * Math.max(0, z.r - p[2]) * .85;
  z.tx = z.x + Math.cos(a) * d; z.ty = z.y + Math.sin(a) * d; z.tr = p[2];
  z.state = 'wait'; z.t = p[0]; z.dps = p[3];
}
function updateZone(dt) {
  const z = G.zone; if (z.final) return;
  const p = ZP[z.phase];
  if (z.state === 'wait') {
    z.t -= dt;
    if (z.t <= 0) { z.state = 'shrink'; z.t = p[1]; z.fx = z.x; z.fy = z.y; z.fr = z.r; say('زون سکڑ رہا ہے!'); }
  } else {
    z.t -= dt;
    const k = clamp(1 - z.t / p[1], 0, 1);
    z.x = z.fx + (z.tx - z.fx) * k; z.y = z.fy + (z.ty - z.fy) * k; z.r = z.fr + (z.tr - z.fr) * k;
    if (z.t <= 0) { z.x = z.tx; z.y = z.ty; z.r = z.tr; nextPhase(); if (!z.final) say('نیا زون نشان زد ہو گیا'); }
  }
}

// ----- ہتھیار -----
function curW(e) { const s = e.slots[e.cur]; return s ? WEAP[s.w] : null; }
function startReload(e) {
  const s = e.slots[e.cur]; if (!s || e.reloadT > 0 || e.healT > 0) return;
  const w = WEAP[s.w]; if (s.mag >= w.mag || e.ammo[w.ammo] <= 0) return;
  e.reloadT = w.rel; if (e.isPlayer) snd('reload');
}
function switchSlot(e, i) {
  if (e.cur === i || !e.slots[i]) return;
  e.cur = i; e.reloadT = 0; if (e.isPlayer) snd('reload');
}
function tryShoot(e) {
  const s = e.slots[e.cur]; if (!s || e.reloadT > 0 || e.fireCd > 0 || e.healT > 0) return false;
  const w = WEAP[s.w];
  if (s.mag <= 0) { startReload(e); return false; }
  s.mag--; e.fireCd = w.rate; e.flash = .06;
  const sm = e.isPlayer ? 1 : DIFFS[G.diff].spr;
  const c = Math.cos(e.ang), sn = Math.sin(e.ang);
  for (let i = 0; i < w.pel; i++) {
    const a = e.ang + (R() - .5) * 2 * w.spr * sm, ca = Math.cos(a), sa = Math.sin(a);
    G.bullets.push({ x: e.x + c * 20, y: e.y + sn * 20, px: e.x + c * 20, py: e.y + sn * 20, vx: ca * w.spd, vy: sa * w.spd,
      dmg: w.dmg * (e.isPlayer ? 1 : DIFFS[G.diff].dmg), life: w.range / w.spd, owner: e, w: s.w });
  }
  snd(s.w, e.x, e.y);
  if (s.mag <= 0) startReload(e);
  return true;
}
function throwGren(e, tx, ty) {
  if (e.gren <= 0 || !e.alive) return;
  e.gren--;
  let dx = tx - e.x, dy = ty - e.y; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
  const sp = clamp(d * 1.4, 160, 420);
  G.grens.push({ x: e.x + dx * 20, y: e.y + dy * 20, vx: dx * sp, vy: dy * sp, t: 1.5, owner: e });
}
function startHeal(e, kind) {
  if (e.healT > 0 || e.hp >= 100) return;
  if (kind === 'med' && e.med > 0) { e.healKind = 'med'; e.healT = e.healTot = 2.4; }
  else if (kind === 'band' && e.band > 0) { e.healKind = 'band'; e.healT = e.healTot = 1.0; }
  else return;
  e.reloadT = 0; if (e.isPlayer) snd('heal');
}
function finishHeal(e) {
  if (e.healKind === 'med') { e.med--; e.hp = Math.min(100, e.hp + 60); }
  else if (e.healKind === 'band') { e.band--; e.hp = Math.min(100, e.hp + 20); }
  if (e.isPlayer) ftext(e.x, e.y - 24, '+صحت', '#41d36b');
  e.healKind = '';
}

// ----- نقصان اور موت -----
function damage(t, dmg, att, cause) {
  if (!t.alive) return;
  const ab = Math.min(t.armor, dmg * .6); t.armor -= ab; const real = dmg - ab; t.hp -= real;
  t.hitT = G.t; t.hitBy = att;
  if (att) att.dmgDone += real;
  if (t.isPlayer) { G.dmgFlash = .25; G.shake = .15; try { navigator.vibrate && navigator.vibrate(30); } catch (e) {} snd('hit'); }
  if (att && att.isPlayer) { ftext(t.x, t.y - 20, '' + Math.round(dmg), '#ffe082'); snd('hit'); }
  if (t.hp <= 0) die(t, att, cause);
}
function dropLoot(e) {
  for (const s of e.slots) if (s) { addLoot(e.x + rnd(-22, 22), e.y + rnd(-22, 22), s.w, s.mag); }
  for (const k of ['l', 'h', 's']) if (e.ammo[k] >= 10) addLoot(e.x + rnd(-22, 22), e.y + rnd(-22, 22), 'ammo_' + k, Math.floor(e.ammo[k] / 2));
  if (e.med) addLoot(e.x + rnd(-20, 20), e.y + rnd(-20, 20), 'med', 1);
  if (e.band) addLoot(e.x + rnd(-20, 20), e.y + rnd(-20, 20), 'band', 1);
  if (e.gren) addLoot(e.x + rnd(-20, 20), e.y + rnd(-20, 20), 'gren', 1);
  if (e.armor > 30) addLoot(e.x + rnd(-20, 20), e.y + rnd(-20, 20), 'armor1', 1);
}
function aliveCount() { let n = 0; for (const e of G.ents) if (e.alive) n++; return n; }
function die(e, killer, cause) {
  e.alive = false; e.hp = 0; e.deadAt = G.t; dropLoot(e);
  fx('boom', e.x, e.y, { r: 30, c: '#ff5252' }); snd('die', e.x, e.y);
  if (killer && killer !== e) { killer.kills++; feed(killer.name + ' نے ' + e.name + ' کو مارا'); }
  else if (cause === 'zone') feed(e.name + ' زون میں ختم ہو گیا');
  else feed(e.name + ' ختم ہو گیا');
  e.rank = aliveCount() + 1;
  if (e.isPlayer) { G.deadT = G.t; }
  else if (killer && killer.isPlayer) say('آپ نے ' + e.name + ' کو مارا');
}

// ----- اٹھانا -----
function wantItem(e, it) {
  if (WEAP[it.t]) {
    for (const s of e.slots) if (s && s.w === it.t) return true;
    if (!e.slots[0] || !e.slots[1]) return true;
    if (e.isPlayer) return false;
    return Math.min(WEAP[e.slots[0].w].val, WEAP[e.slots[1].w].val) < WEAP[it.t].val;
  }
  switch (it.t) {
    case 'ammo_l': return e.ammo.l < 200; case 'ammo_h': return e.ammo.h < 200; case 'ammo_s': return e.ammo.s < 60;
    case 'med': return e.med < 4; case 'band': return e.band < 8; case 'gren': return e.gren < 5;
    case 'armor1': return e.armor < 100; case 'armor2': return e.armor < 100;
  }
  return false;
}
function applyItem(e, it) {
  const w = WEAP[it.t];
  if (w) {
    for (const s of e.slots) if (s && s.w === it.t) { e.ammo[w.ammo] += it.n; return; }
    let i = !e.slots[0] ? 0 : (!e.slots[1] ? 1 : -1);
    if (i < 0) { // بوٹ: کم قیمت والا بدلے
      i = WEAP[e.slots[0].w].val <= WEAP[e.slots[1].w].val ? 0 : 1;
      const old = e.slots[i]; addLoot(e.x + rnd(-12, 12), e.y + rnd(-12, 12), old.w, old.mag);
    }
    e.slots[i] = { w: it.t, mag: it.n };
    if (e.isPlayer && (!e.slots[e.cur] || i !== e.cur) && WEAP[e.slots[e.cur] ? e.slots[e.cur].w : 'pistol'].val < w.val) switchSlot(e, i);
    return;
  }
  switch (it.t) {
    case 'ammo_l': e.ammo.l += it.n; break; case 'ammo_h': e.ammo.h += it.n; break; case 'ammo_s': e.ammo.s += it.n; break;
    case 'med': e.med++; break; case 'band': e.band++; break; case 'gren': e.gren++; break;
    case 'armor1': e.armor = Math.min(100, e.armor + 40); break;
    case 'armor2': e.armor = Math.min(100, e.armor + 80); break;
  }
}
function pickupNear(e) {
  const loot = G.loot;
  for (let i = loot.length - 1; i >= 0; i--) {
    const it = loot[i];
    if (Math.abs(it.x - e.x) > 40 || Math.abs(it.y - e.y) > 40) continue;
    if (Math.hypot(it.x - e.x, it.y - e.y) > e.r + 24) continue;
    if (!wantItem(e, it)) continue;
    applyItem(e, it); loot.splice(i, 1);
    if (e.isPlayer) { snd('pick'); ftext(e.x, e.y - 24, WEAP[it.t] ? WEAP[it.t].n : ITEMN[it.t], '#ffffff'); }
  }
}
// کھلاڑی: بٹن سے ہتھیار بدلنا
function nearestWeaponItem(e) {
  let best = null, bd = 60;
  for (const it of G.loot) if (WEAP[it.t]) { const d = Math.hypot(it.x - e.x, it.y - e.y); if (d < bd) { bd = d; best = it; } }
  return best;
}
function playerPickBtn() {
  const e = G.player; if (!e.alive) return;
  const it = nearestWeaponItem(e); if (!it) return;
  if (!wantItem(e, it)) { // جگہ بھری ہے: موجودہ ہتھیار بدلو
    const old = e.slots[e.cur];
    G.loot.splice(G.loot.indexOf(it), 1);
    if (old) addLoot(e.x + rnd(-10, 10), e.y + rnd(-10, 10), old.w, old.mag);
    e.slots[e.cur] = { w: it.t, mag: it.n }; e.reloadT = 0;
  } else { applyItem(e, it); G.loot.splice(G.loot.indexOf(it), 1); }
  snd('pick');
}

// ----- ہر فریم میں ایک کھلاڑی کی حرکت -----
function stepEnt(e, dt) {
  if (!e.alive) return;
  e.fireCd = Math.max(0, e.fireCd - dt); e.flash = Math.max(0, e.flash - dt);
  if (e.reloadT > 0) {
    e.reloadT -= dt;
    if (e.reloadT <= 0) {
      e.reloadT = 0; const s = e.slots[e.cur];
      if (s) { const w = WEAP[s.w], take = Math.min(w.mag - s.mag, e.ammo[w.ammo]); s.mag += take; e.ammo[w.ammo] -= take; }
    }
  }
  if (e.healT > 0) { e.healT -= dt; if (e.healT <= 0) { e.healT = 0; finishHeal(e); } }
  let sp = e.isPlayer ? 150 : 138;
  const w = curW(e); if (w && w === WEAP.sniper) sp *= .92;
  if (e.healT > 0) sp *= .5; else if (e.reloadT > 0) sp *= .88;
  let mx = e.mx, my = e.my; const l = Math.hypot(mx, my);
  if (l > 1) { mx /= l; my /= l; }
  const ox = e.x, oy = e.y;
  e.x += mx * sp * dt; e.y += my * sp * dt; collide(e);
  e.vx = (e.x - ox) / dt; e.vy = (e.y - oy) / dt;
  if (e.fire && e.healT <= 0) tryShoot(e);
  pickupNear(e);
  const z = G.zone;
  if (Math.hypot(e.x - z.x, e.y - z.y) > z.r) {
    e.hp -= z.dps * dt; e.inZone = false;
    if (e.isPlayer) G.zoneWarn = .3;
    if (e.hp <= 0) die(e, null, 'zone');
  }
}
function separate() {
  const a = G.ents;
  for (let i = 0; i < a.length; i++) { const p = a[i]; if (!p.alive) continue;
    for (let j = i + 1; j < a.length; j++) { const q = a[j]; if (!q.alive) continue;
      const dx = q.x - p.x, dy = q.y - p.y; if (dx > 30 || dx < -30 || dy > 30 || dy < -30) continue;
      const d = Math.hypot(dx, dy), m = p.r + q.r;
      if (d < m && d > 1e-3) { const k = (m - d) / 2 / d; p.x -= dx * k; p.y -= dy * k; q.x += dx * k; q.y += dy * k; }
    } }
}

// ----- گولیاں اور بم -----
function updateBullets(dt) {
  const bs = G.bullets;
  for (let i = bs.length - 1; i >= 0; i--) {
    const b = bs[i]; b.px = b.x; b.py = b.y; b.x += b.vx * dt; b.y += b.vy * dt; b.life -= dt;
    let tBest = rayObs(b.px, b.py, b.x, b.y), hitE = null;
    for (const e of G.ents) {
      if (!e.alive || e === b.owner) continue;
      if (Math.abs(e.x - b.x) > 80 && Math.abs(e.x - b.px) > 80) continue;
      const t = segCircle(b.px, b.py, b.x, b.y, e.x, e.y, e.r + 2);
      if (t < tBest) { tBest = t; hitE = e; }
    }
    if (hitE) { fx('spark', b.px + (b.x - b.px) * tBest, b.py + (b.y - b.py) * tBest, { c: '#ff8a80' }); damage(hitE, b.dmg, b.owner, b.w); bs.splice(i, 1); }
    else if (tBest < 1) { fx('spark', b.px + (b.x - b.px) * tBest, b.py + (b.y - b.py) * tBest, { c: '#ffe082' }); bs.splice(i, 1); }
    else if (b.life <= 0 || b.x < 0 || b.y < 0 || b.x > W || b.y > H) bs.splice(i, 1);
  }
}
function explode(g) {
  fx('boom', g.x, g.y, { r: 110, c: '#ffab40' }); snd('boom', g.x, g.y);
  if (Math.hypot(g.x - G.player.x, g.y - G.player.y) < 400) G.shake = .35;
  for (const e of G.ents) {
    if (!e.alive) continue; const d = Math.hypot(e.x - g.x, e.y - g.y);
    if (d < 110 && rayObs(g.x, g.y, e.x, e.y) >= 1) damage(e, 95 * (1 - d / 125), g.owner, 'gren');
  }
}
function updateGrens(dt) {
  for (let i = G.grens.length - 1; i >= 0; i--) {
    const g = G.grens[i]; g.t -= dt;
    const nx = g.x + g.vx * dt, ny = g.y + g.vy * dt;
    if (rayObs(g.x, g.y, nx, ny) < 1 || blockedPt(nx, ny, 5)) { g.vx *= -.3; g.vy *= -.3; } else { g.x = nx; g.y = ny; }
    const f = Math.pow(.12, dt); g.vx *= f; g.vy *= f;
    if (g.t <= 0) { explode(g); G.grens.splice(i, 1); }
  }
}

// ----- مکمل اپڈیٹ -----
function update(dt) {
  if (!G || !G.running) return;
  G.t += dt;
  updateZone(dt);
  playerControl(G.player, dt);
  for (const e of G.ents) { if (!e.alive) continue; if (!e.isPlayer) botAI(e, dt); stepEnt(e, dt); }
  separate();
  updateBullets(dt); updateGrens(dt);
  for (let i = G.fx.length - 1; i >= 0; i--) { const f = G.fx[i]; f.t += dt; if (f.t > .5) G.fx.splice(i, 1); }
  for (let i = G.texts.length - 1; i >= 0; i--) { const f = G.texts[i]; f.t += dt; f.y -= 30 * dt; if (f.t > .9) G.texts.splice(i, 1); }
  for (let i = G.feed.length - 1; i >= 0; i--) { G.feed[i].t -= dt; if (G.feed[i].t <= 0) G.feed.splice(i, 1); }
  G.msgT = Math.max(0, G.msgT - dt); G.dmgFlash = Math.max(0, G.dmgFlash - dt); G.shake = Math.max(0, G.shake - dt);
  G.zoneWarn = Math.max(0, G.zoneWarn - dt);
  // جیت یا ہار
  const n = aliveCount();
  if (!G.over) {
    if (G.player.alive && n === 1) { G.over = true; G.win = true; G.overT = G.t; say('آپ جیت گئے!'); }
    else if (!G.player.alive && G.t - G.deadT > 1.6) { G.over = true; G.win = false; G.overT = G.t; }
  }
}
