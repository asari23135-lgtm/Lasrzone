'use strict';
// ===== نقشہ اور رکاوٹیں =====
const CS = 200, GN = Math.ceil(W / CS);
let grid = [], buildings = [], stamp = 0;

function addObs(o) {
  const x0 = o.k === 0 ? o.x - o.r : o.x0, x1 = o.k === 0 ? o.x + o.r : o.x1;
  const y0 = o.k === 0 ? o.y - o.r : o.y0, y1 = o.k === 0 ? o.y + o.r : o.y1;
  o.bx0 = x0; o.by0 = y0; o.bx1 = x1; o.by1 = y1; o.q = 0;
  const cx0 = clamp((x0 / CS) | 0, 0, GN - 1), cx1 = clamp((x1 / CS) | 0, 0, GN - 1);
  const cy0 = clamp((y0 / CS) | 0, 0, GN - 1), cy1 = clamp((y1 / CS) | 0, 0, GN - 1);
  for (let cy = cy0; cy <= cy1; cy++) for (let cx = cx0; cx <= cx1; cx++) grid[cy * GN + cx].push(o);
}
function queryObs(x0, y0, x1, y1, fn) {
  stamp++;
  const cx0 = clamp((x0 / CS) | 0, 0, GN - 1), cx1 = clamp((x1 / CS) | 0, 0, GN - 1);
  const cy0 = clamp((y0 / CS) | 0, 0, GN - 1), cy1 = clamp((y1 / CS) | 0, 0, GN - 1);
  for (let cy = cy0; cy <= cy1; cy++) for (let cx = cx0; cx <= cx1; cx++) {
    const c = grid[cy * GN + cx];
    for (let i = 0; i < c.length; i++) { const o = c[i]; if (o.q !== stamp) { o.q = stamp; fn(o); } }
  }
}

function collide(e) {
  queryObs(e.x - e.r - 2, e.y - e.r - 2, e.x + e.r + 2, e.y + e.r + 2, o => {
    if (o.k === 0) {
      const dx = e.x - o.x, dy = e.y - o.y, d = Math.hypot(dx, dy), m = e.r + o.r;
      if (d < m) { if (d < 1e-4) e.x += m; else { e.x += dx / d * (m - d); e.y += dy / d * (m - d); } }
    } else {
      const cx = clamp(e.x, o.x0, o.x1), cy = clamp(e.y, o.y0, o.y1);
      const dx = e.x - cx, dy = e.y - cy, d2 = dx * dx + dy * dy;
      if (d2 < e.r * e.r) {
        if (d2 > 1e-6) { const d = Math.sqrt(d2); e.x += dx / d * (e.r - d); e.y += dy / d * (e.r - d); }
        else {
          const l = e.x - o.x0, r = o.x1 - e.x, t = e.y - o.y0, b = o.y1 - e.y, m = Math.min(l, r, t, b);
          if (m === l) e.x = o.x0 - e.r; else if (m === r) e.x = o.x1 + e.r;
          else if (m === t) e.y = o.y0 - e.r; else e.y = o.y1 + e.r;
        }
      }
    }
  });
  e.x = clamp(e.x, e.r, W - e.r); e.y = clamp(e.y, e.r, H - e.r);
}

function segCircle(x1, y1, x2, y2, cx, cy, r) {
  const dx = x2 - x1, dy = y2 - y1, fx = x1 - cx, fy = y1 - cy, a = dx * dx + dy * dy;
  if (a < 1e-9) return 2;
  const b = 2 * (fx * dx + fy * dy), c = fx * fx + fy * fy - r * r;
  if (c <= 0) return 0;
  const disc = b * b - 4 * a * c;
  if (disc < 0) return 2;
  const t = (-b - Math.sqrt(disc)) / (2 * a);
  return (t >= 0 && t <= 1) ? t : 2;
}
function segRect(x1, y1, x2, y2, rx0, ry0, rx1, ry1) {
  let tmin = 0, tmax = 1; const dx = x2 - x1, dy = y2 - y1;
  if (Math.abs(dx) < 1e-9) { if (x1 < rx0 || x1 > rx1) return 2; }
  else { let a = (rx0 - x1) / dx, b = (rx1 - x1) / dx; if (a > b) { const t = a; a = b; b = t; } tmin = Math.max(tmin, a); tmax = Math.min(tmax, b); if (tmin > tmax) return 2; }
  if (Math.abs(dy) < 1e-9) { if (y1 < ry0 || y1 > ry1) return 2; }
  else { let a = (ry0 - y1) / dy, b = (ry1 - y1) / dy; if (a > b) { const t = a; a = b; b = t; } tmin = Math.max(tmin, a); tmax = Math.min(tmax, b); if (tmin > tmax) return 2; }
  return tmin;
}
// پہلی رکاوٹ تک کا حصہ (1 = راستہ صاف)
function rayObs(x1, y1, x2, y2) {
  let best = 1;
  queryObs(Math.min(x1, x2) - 4, Math.min(y1, y2) - 4, Math.max(x1, x2) + 4, Math.max(y1, y2) + 4, o => {
    if (!o.bl) return;
    const t = o.k === 0 ? segCircle(x1, y1, x2, y2, o.x, o.y, o.r) : segRect(x1, y1, x2, y2, o.x0, o.y0, o.x1, o.y1);
    if (t < best) best = t;
  });
  return best;
}
function blockedPt(x, y, r) {
  let hit = false;
  queryObs(x - r, y - r, x + r, y + r, o => {
    if (hit) return;
    if (o.k === 0) { if (Math.hypot(x - o.x, y - o.y) < r + o.r) hit = true; }
    else { const cx = clamp(x, o.x0, o.x1), cy = clamp(y, o.y0, o.y1); if (Math.hypot(x - cx, y - cy) < r) hit = true; }
  });
  return hit;
}
function inB(x, y, m) {
  for (const b of buildings) if (x > b.x - m && x < b.x + b.w + m && y > b.y - m && y < b.y + b.h + m) return b;
  return null;
}

// ===== نقشہ بنانا =====
const T = 14, DW = 64;
function wall(x0, y0, x1, y1) { addObs({ k: 1, x0, y0, x1, y1, bl: true, wall: true }); }
function genMap() {
  grid = []; for (let i = 0; i < GN * GN; i++) grid.push([]);
  buildings = [];
  let tries = 0;
  while (buildings.length < 22 && tries++ < 600) {
    const w = rnd(180, 280) | 0, h = rnd(150, 230) | 0, x = rnd(220, W - 220 - w) | 0, y = rnd(220, H - 220 - h) | 0;
    let ok = true;
    for (const b of buildings) if (x < b.x + b.w + 110 && x + w + 110 > b.x && y < b.y + b.h + 110 && y + h + 110 > b.y) { ok = false; break; }
    if (!ok) continue;
    const b = { x, y, w, h, doors: [], crates: [], fl: pick(['#7a6548', '#6d6f73', '#5f6b5a', '#7b5e57']) };
    const sides = [0, 1, 2, 3].sort(() => R() - .5).slice(0, 2);
    const gaps = {};
    for (const s of sides) {
      if (s < 2) { const g = x + 50 + R() * (w - 100 - DW), c = g + DW / 2; gaps[s] = [g, g + DW];
        b.doors.push(s === 0 ? { ox: c, oy: y - 24, ix: c, iy: y + T + 24 } : { ox: c, oy: y + h + 24, ix: c, iy: y + h - T - 24 }); }
      else { const g = y + 50 + R() * (h - 100 - DW), c = g + DW / 2; gaps[s] = [g, g + DW];
        b.doors.push(s === 2 ? { ox: x - 24, oy: c, ix: x + T + 24, iy: c } : { ox: x + w + 24, oy: c, ix: x + w - T - 24, iy: c }); }
    }
    // چار دیواریں (دروازے کی خالی جگہ کے ساتھ)
    const hw = (yy0, yy1, gp) => { if (gp) { wall(x, yy0, gp[0], yy1); wall(gp[1], yy0, x + w, yy1); } else wall(x, yy0, x + w, yy1); };
    const vw = (xx0, xx1, gp) => { if (gp) { wall(xx0, y, xx1, gp[0]); wall(xx0, gp[1], xx1, y + h); } else wall(xx0, y, xx1, y + h); };
    hw(y, y + T, gaps[0]); hw(y + h - T, y + h, gaps[1]);
    vw(x, x + T, gaps[2]); vw(x + w - T, x + w, gaps[3]);
    // کونوں میں ڈبے
    const cc = [[x + T + 6, y + T + 6], [x + w - T - 32, y + T + 6], [x + T + 6, y + h - T - 32], [x + w - T - 32, y + h - T - 32]];
    for (const c of cc.sort(() => R() - .5).slice(0, 2)) { b.crates.push({ x: c[0], y: c[1] }); addObs({ k: 1, x0: c[0], y0: c[1], x1: c[0] + 26, y1: c[1] + 26, bl: true, crate: true }); }
    buildings.push(b);
  }
  for (let i = 0; i < 380; i++) {
    const x = rnd(40, W - 40), y = rnd(40, H - 40);
    if (inB(x, y, 50)) continue;
    addObs({ k: 0, x, y, r: rnd(18, 28), bl: false, tree: true, sh: R() });
  }
  for (let i = 0; i < 90; i++) {
    const x = rnd(40, W - 40), y = rnd(40, H - 40);
    if (inB(x, y, 50)) continue;
    addObs({ k: 0, x, y, r: rnd(14, 24), bl: true, rock: true, sh: R() });
  }
}
function blockedAny(x, y, r) { return blockedPt(x, y, r); }
