'use strict';
// ===== کنٹرول، HUD، مینو =====
const $ = id => document.getElementById(id);
const IN = { kx: 0, ky: 0, mouseDown: false, mouseAng: null, move: null, aim: null };
const touchEl = $('touch'), SR = 55;
let wake = null;

function setStick(el, x, y, kx, ky) {
  el.classList.remove('hide'); el.style.left = x + 'px'; el.style.top = y + 'px';
  el.firstElementChild.style.transform = 'translate(' + kx + 'px,' + ky + 'px)';
}
function stickVec(t) {
  let dx = t.x - t.x0, dy = t.y - t.y0; const l = Math.hypot(dx, dy);
  if (l > SR) { dx = dx / l * SR; dy = dy / l * SR; }
  return [dx, dy];
}
touchEl.addEventListener('pointerdown', e => {
  e.preventDefault(); if (!G || !G.running || G.paused) return; initAudio();
  if (e.pointerType === 'mouse') { IN.mouseDown = true; mouseAim(e); return; }
  const left = e.clientX < vw * .45;
  const t = { id: e.pointerId, x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY };
  if (left && !IN.move) { IN.move = t; setStick($('stickM'), t.x0, t.y0, 0, 0); }
  else if (!left && !IN.aim) { IN.aim = t; t.a = null; setStick($('stickA'), t.x0, t.y0, 0, 0); }
  try { touchEl.setPointerCapture(e.pointerId); } catch (er) {}
});
touchEl.addEventListener('pointermove', e => {
  if (e.pointerType === 'mouse') { mouseAim(e); return; }
  for (const k of ['move', 'aim']) {
    const t = IN[k]; if (t && t.id === e.pointerId) {
      t.x = e.clientX; t.y = e.clientY;
      const [dx, dy] = stickVec(t); setStick($(k === 'move' ? 'stickM' : 'stickA'), t.x0, t.y0, dx, dy);
    }
  }
});
function endPtr(e) {
  if (e.pointerType === 'mouse') { IN.mouseDown = false; return; }
  if (IN.move && IN.move.id === e.pointerId) { IN.move = null; $('stickM').classList.add('hide'); }
  if (IN.aim && IN.aim.id === e.pointerId) { IN.aim = null; $('stickA').classList.add('hide'); }
}
touchEl.addEventListener('pointerup', endPtr); touchEl.addEventListener('pointercancel', endPtr);
function mouseAim(e) { IN.mouseAng = Math.atan2(e.clientY - vh / 2, e.clientX - vw / 2); }
const KEYS = {};
addEventListener('keydown', e => {
  if (e.target && e.target.tagName === 'INPUT') return;
  KEYS[e.code] = true; initAudio();
  if (!G || !G.running) return;
  if (e.code === 'KeyR') startReload(G.player);
  if (e.code === 'KeyE') playerPickBtn();
  if (e.code === 'Digit1') switchSlot(G.player, 0);
  if (e.code === 'Digit2') switchSlot(G.player, 1);
  if (e.code === 'KeyG') throwGren(G.player, G.player.x + Math.cos(G.player.ang) * 260, G.player.y + Math.sin(G.player.ang) * 260);
  if (e.code === 'KeyF') startHeal(G.player, 'band');
  if (e.code === 'KeyQ') startHeal(G.player, 'med');
});
addEventListener('keyup', e => { KEYS[e.code] = false; });

function playerControl(p, dt) {
  if (!p.alive) { p.mx = p.my = 0; p.fire = false; return; }
  let mx = (KEYS.KeyD || KEYS.ArrowRight ? 1 : 0) - (KEYS.KeyA || KEYS.ArrowLeft ? 1 : 0);
  let my = (KEYS.KeyS || KEYS.ArrowDown ? 1 : 0) - (KEYS.KeyW || KEYS.ArrowUp ? 1 : 0);
  if (IN.move) { const [dx, dy] = stickVec(IN.move); const l = Math.hypot(dx, dy) / SR; if (l > .12) { mx += dx / SR / Math.max(l, .001) * Math.min(1, l * 1.15); my += dy / SR / Math.max(l, .001) * Math.min(1, l * 1.15); } }
  p.mx = mx; p.my = my;
  let fire = IN.mouseDown || !!KEYS.Space;
  if (IN.mouseAng !== null && !IN.aim) p.ang = IN.mouseAng;
  if (IN.aim) {
    const [dx, dy] = stickVec(IN.aim);
    if (Math.hypot(dx, dy) > 10) p.ang = Math.atan2(dy, dx);
    fire = true; assist(p);
  }
  p.fire = fire;
}
function assist(e) {
  const w = curW(e); if (!w) return;
  let best = null, bd = 1e9;
  for (const o of G.ents) {
    if (o === e || !o.alive) continue;
    const dx = o.x - e.x, dy = o.y - e.y, d = Math.hypot(dx, dy); if (d > w.range * .9) continue;
    const da = Math.abs(angDiff(e.ang, Math.atan2(dy, dx)));
    if (da < .3 && da * d < bd && rayObs(e.x, e.y, o.x, o.y) >= 1) { best = o; bd = da * d; }
  }
  if (best) e.ang += angDiff(e.ang, Math.atan2(best.y - e.y, best.x - e.x)) * .22;
}

// ----- بٹن -----
function bind(id, fn) { $(id).addEventListener('pointerdown', ev => { ev.preventDefault(); ev.stopPropagation(); initAudio(); if (G && G.running && !G.paused) fn(); }); }
bind('bRel', () => startReload(G.player));
bind('bPick', () => playerPickBtn());
bind('bGren', () => throwGren(G.player, G.player.x + Math.cos(G.player.ang) * 260, G.player.y + Math.sin(G.player.ang) * 260));
bind('bBand', () => startHeal(G.player, 'band'));
bind('bMed', () => startHeal(G.player, 'med'));
$('bSnd').addEventListener('pointerdown', ev => { ev.preventDefault(); sfxOn = !sfxOn; $('bSnd').style.opacity = sfxOn ? 1 : .45; });
for (const i of [0, 1]) $('s' + i).addEventListener('pointerdown', ev => { ev.preventDefault(); if (G && G.running) switchSlot(G.player, i); });
$('pauseBtn').addEventListener('pointerdown', ev => { ev.preventDefault(); setPause(true); });
$('resume').addEventListener('click', () => setPause(false));
$('quit').addEventListener('click', () => { setPause(false); toMenu(); });
function setPause(v) { if (!G || G.over && v) return; G.paused = v; $('pause').classList.toggle('hide', !v); if (v) { IN.move = IN.aim = null; $('stickM').classList.add('hide'); $('stickA').classList.add('hide'); } }
document.addEventListener('visibilitychange', () => { if (document.hidden && G && G.running && !G.over) setPause(true); });

// ----- HUD -----
const HC = {};
function setT(id, v) { if (HC[id] !== v) { HC[id] = v; $(id).textContent = v; } }
function setH(id, v) { if (HC[id] !== v) { HC[id] = v; $(id).innerHTML = v; } }
function slotHtml(e, i) {
  const s = e.slots[i]; if (!s) return '<span style="opacity:.5">خالی</span>';
  const w = WEAP[s.w]; return w.n + '<small class="n">' + s.mag + ' / ' + e.ammo[w.ammo] + '</small>';
}
function hud() {
  const p = G.player, z = G.zone;
  setT('cAlive', 'زندہ: ' + aliveCount()); setT('cKills', 'مار گرائے: ' + p.kills);
  let zt;
  if (z.final) zt = 'آخری زون!';
  else if (z.state === 'wait') zt = 'مرحلہ ' + (z.phase + 1) + ' : زون ' + Math.ceil(z.t) + ' سیکنڈ میں سکڑے گا';
  else zt = 'مرحلہ ' + (z.phase + 1) + ' : زون سکڑ رہا ہے ' + Math.ceil(z.t);
  setT('zoneTxt', zt);
  $('hpF').style.width = clamp(p.hp, 0, 100) + '%'; $('arF').style.width = clamp(p.armor, 0, 100) + '%';
  setT('hpT', Math.ceil(Math.max(0, p.hp))); setT('arT', Math.ceil(p.armor));
  setH('s0', slotHtml(p, 0)); setH('s1', slotHtml(p, 1));
  $('s0').classList.toggle('on', p.cur === 0); $('s1').classList.toggle('on', p.cur === 1);
  setT('nGren', p.gren); setT('nBand', p.band); setT('nMed', p.med);
  $('bPick').classList.toggle('glow', !!nearestWeaponItem(p));
  let f = ''; for (const x of G.feed) f += '<div>' + x.s + '</div>'; setH('feed', f);
  const m = $('msg'); setT('msg', G.msg); m.style.opacity = G.msgT > 0 ? 1 : 0;
  $('warn').style.opacity = G.zoneWarn > 0 || (p.alive && p.hp < 25) ? .8 : (G.dmgFlash > 0 ? .45 : 0);
  const pr = $('prog');
  if (p.healT > 0) { pr.style.opacity = 1; $('progF').style.width = (100 - p.healT / p.healTot * 100) + '%'; }
  else if (p.reloadT > 0 && curW(p)) { pr.style.opacity = 1; $('progF').style.width = (100 - p.reloadT / curW(p).rel * 100) + '%'; }
  else pr.style.opacity = 0;
}

// ----- مینو اور اختتام -----
let diff = load('lz_diff', 1);
function showStats() { const s = load('lz_stats', { games: 0, wins: 0, best: 0, kills: 0 }); $('stats').textContent = 'کھیل: ' + s.games + '  |  جیت: ' + s.wins + '  |  زیادہ سے زیادہ مار گرائے: ' + s.best; }
function paintDiff() { document.querySelectorAll('.dif').forEach(b => b.classList.toggle('on', +b.dataset.d === diff)); }
document.querySelectorAll('.dif').forEach(b => b.addEventListener('click', () => { diff = +b.dataset.d; save('lz_diff', diff); paintDiff(); }));
$('nm').value = load('lz_name', '');
function startGame() {
  initAudio();
  const nm = $('nm').value.trim() || 'آپ'; save('lz_name', $('nm').value.trim());
  miniBg = null; newGame(nm, diff);
  camX = G.player.x; camY = G.player.y;
  for (const k in HC) delete HC[k];
  ['menu', 'over', 'pause'].forEach(i => $(i).classList.add('hide')); $('hud').classList.remove('hide');
  try { if (navigator.wakeLock) navigator.wakeLock.request('screen').then(w => wake = w).catch(() => {}); } catch (e) {}
}
function toMenu() { if (G) G.running = false; G = null; ['over', 'pause', 'hud'].forEach(i => $(i).classList.add('hide')); $('menu').classList.remove('hide'); showStats(); }
function showOver() {
  const p = G.player, win = G.win; G.endShown = true;
  const rank = win ? 1 : (p.rank || 2);
  $('ovT').textContent = win ? 'مبارک ہو! آپ چیمپئن ہیں' : 'کھیل ختم';
  $('ovR').textContent = '#' + rank;
  $('ovS').textContent = 'مار گرائے: ' + p.kills + '   |   نقصان: ' + Math.round(p.dmgDone) + '   |   وقت: ' + Math.floor(G.t / 60) + ':' + ('0' + Math.floor(G.t % 60)).slice(-2);
  const s = load('lz_stats', { games: 0, wins: 0, best: 0, kills: 0 });
  s.games++; if (win) s.wins++; s.best = Math.max(s.best, p.kills); s.kills += p.kills; save('lz_stats', s);
  $('over').classList.remove('hide'); IN.move = IN.aim = null;
  $('stickM').classList.add('hide'); $('stickA').classList.add('hide');
}
$('play').addEventListener('click', startGame);
$('again').addEventListener('click', startGame);
$('toMenu').addEventListener('click', toMenu);
paintDiff(); showStats();

// ----- لوپ -----
let last = performance.now();
function frame(now) {
  const dt = Math.min(.05, (now - last) / 1000); last = now;
  if (G && G.running && !G.paused) {
    update(dt);
    hud();
    if (G.over && !G.endShown && G.t - G.overT > (G.win ? 1.5 : 0)) showOver();
  }
  render();
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);
window.__dbg = { get G() { return G; }, step: dt => update(dt), start: startGame, render, hud };
