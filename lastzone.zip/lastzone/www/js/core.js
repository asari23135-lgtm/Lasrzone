'use strict';
// ===== بنیادی چیزیں =====
const W = 4000, H = 4000;
const TAU = Math.PI * 2, R = Math.random;
const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
const rnd = (a, b) => a + R() * (b - a);
const pick = a => a[(R() * a.length) | 0];
function angDiff(a, b) { let d = b - a; while (d > Math.PI) d -= TAU; while (d < -Math.PI) d += TAU; return d; }

const WEAP = {
  pistol:  { n: 'پستول',     dmg: 16, rate: .34, mag: 12, spd: 950,  range: 520,  spr: .035, ammo: 'l', rel: 1.1, len: 14, val: 1,   pel: 1, col: '#cfd8dc' },
  smg:     { n: 'ایس ایم جی', dmg: 8, rate: .075, mag: 30, spd: 1000, range: 470,  spr: .09,  ammo: 'l', rel: 1.6, len: 20, val: 2.5, pel: 1, col: '#80deea' },
  rifle:   { n: 'رائفل',     dmg: 15, rate: .12, mag: 30, spd: 1150, range: 720,  spr: .045, ammo: 'h', rel: 1.9, len: 28, val: 4,   pel: 1, col: '#ffcc80' },
  shotgun: { n: 'شاٹ گن',    dmg: 8,  rate: .85, mag: 6,  spd: 850,  range: 280,  spr: .2,   ammo: 's', rel: 2.2, len: 26, val: 3,   pel: 8, col: '#ef9a9a' },
  sniper:  { n: 'اسنائپر',   dmg: 70, rate: 1.25, mag: 5, spd: 1900, range: 1000, spr: .006, ammo: 'h', rel: 2.6, len: 36, val: 3.2, pel: 1, col: '#ce93d8' }
};
const ITEMN = {
  ammo_l: 'ہلکی گولیاں', ammo_h: 'بھاری گولیاں', ammo_s: 'کارتوس',
  med: 'میڈکٹ', band: 'پٹی', armor1: 'ہلکی جیکٹ', armor2: 'بھاری جیکٹ', gren: 'بم'
};
const ITEMC = {
  ammo_l: '#ffd54f', ammo_h: '#ff8a65', ammo_s: '#e57373', med: '#ffffff', band: '#ffffff',
  armor1: '#64b5f6', armor2: '#1e88e5', gren: '#66bb6a'
};
const LOOT_TABLE = [
  ['pistol', 6], ['smg', 9], ['rifle', 5], ['shotgun', 6], ['sniper', 1.5],
  ['ammo_l', 13], ['ammo_h', 11], ['ammo_s', 6],
  ['med', 5], ['band', 9], ['armor1', 6], ['armor2', 2.5], ['gren', 6]
];
const LOOT_SUM = LOOT_TABLE.reduce((a, b) => a + b[1], 0);
function randLootType() {
  let r = R() * LOOT_SUM;
  for (const [t, w] of LOOT_TABLE) { r -= w; if (r <= 0) return t; }
  return 'band';
}
const ZP = [ // انتظار، سکڑنے کا وقت، نیا رداس، نقصان فی سیکنڈ
  [35, 30, 2200, 1], [25, 25, 1500, 2], [20, 20, 950, 4],
  [15, 16, 550, 6], [12, 14, 250, 9], [10, 10, 30, 14]
];
const DIFFS = [
  { n: 'آسان',    spr: 3.2, react: .9,  dmg: .6, turn: 4,  lead: 0 },
  { n: 'درمیانہ', spr: 2.4, react: .55, dmg: .8, turn: 6,  lead: .4 },
  { n: 'مشکل',    spr: 1.7, react: .3,  dmg: 1,  turn: 9,  lead: .8 }
];
const BOT_NAMES = ['شیر خان', 'بلال', 'حمزہ', 'علی', 'عمر', 'زین', 'فہد', 'کامران', 'ارسلان', 'شاہد',
  'وقاص', 'عمران', 'نعمان', 'فیصل', 'طلحہ', 'دانش', 'سلمان', 'جنید', 'راشد', 'اسد',
  'احمد', 'حسن', 'ذیشان', 'رضوان', 'عدیل', 'یاسر', 'اکرم', 'ثاقب', 'نوید', 'ہارون'];

// ===== آواز =====
let AC = null, noiseBuf = null, sfxOn = true, sndN = 0;
function initAudio() {
  if (AC) { try { AC.resume(); } catch (e) {} return; }
  try {
    AC = new (window.AudioContext || window.webkitAudioContext)();
    const n = AC.sampleRate >> 1;
    noiseBuf = AC.createBuffer(1, n, AC.sampleRate);
    const d = noiseBuf.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = R() * 2 - 1;
  } catch (e) { AC = null; }
}
function sNoise(dur, freq, vol) {
  const s = AC.createBufferSource(); s.buffer = noiseBuf;
  const f = AC.createBiquadFilter(); f.type = 'lowpass'; f.frequency.value = freq;
  const g = AC.createGain(), t = AC.currentTime;
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  s.connect(f); f.connect(g); g.connect(AC.destination);
  s.onended = () => sndN--; sndN++;
  s.start(t); s.stop(t + dur + .02);
}
function sTone(f1, f2, dur, vol, type) {
  const o = AC.createOscillator(); o.type = type || 'sine';
  const g = AC.createGain(), t = AC.currentTime;
  o.frequency.setValueAtTime(f1, t); o.frequency.exponentialRampToValueAtTime(f2, t + dur);
  g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  o.connect(g); g.connect(AC.destination);
  o.onended = () => sndN--; sndN++;
  o.start(t); o.stop(t + dur + .02);
}
function snd(kind, x, y) {
  if (!AC || !sfxOn || sndN > 22) return;
  let vol = 1;
  if (x !== undefined && G && G.player) {
    const d = Math.hypot(x - G.player.x, y - G.player.y);
    vol = clamp(1 - d / 900, 0, 1);
    if (vol < .05) return;
  }
  try {
    switch (kind) {
      case 'pistol': sNoise(.12, 2400, .5 * vol); break;
      case 'smg': sNoise(.08, 3000, .38 * vol); break;
      case 'rifle': sNoise(.14, 1800, .55 * vol); break;
      case 'shotgun': sNoise(.22, 1200, .7 * vol); break;
      case 'sniper': sNoise(.4, 900, .8 * vol); break;
      case 'boom': sNoise(.7, 500, .9 * vol); break;
      case 'hit': sTone(300, 120, .08, .25 * vol, 'square'); break;
      case 'pick': sTone(600, 1000, .1, .2 * vol); break;
      case 'reload': sTone(220, 160, .07, .2 * vol, 'square'); break;
      case 'heal': sTone(500, 800, .25, .2 * vol); break;
      case 'die': sTone(260, 60, .35, .35 * vol, 'sawtooth'); break;
    }
  } catch (e) {}
}

// ===== بچت =====
function load(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } }
function save(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }

// عالمی کھیل کی حالت
let G = null;
