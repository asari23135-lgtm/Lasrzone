'use strict';
// ===== ڈرائنگ =====
const cv = document.getElementById('c'), ctx = cv.getContext('2d');
const mini = document.getElementById('mini'), mctx = mini.getContext('2d');
let vw = 800, vh = 360, dpr = 1, sc = 1, camX = 0, camY = 0, grass = null, miniBg = null;

function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 2); vw = innerWidth; vh = innerHeight;
  cv.width = Math.round(vw * dpr); cv.height = Math.round(vh * dpr);
  sc = Math.max(.55, Math.min(vw, vh) / 560);
}
window.addEventListener('resize', resize); resize();

function makeGrass() {
  const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d');
  g.fillStyle = '#4b7d3b'; g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 260; i++) { g.fillStyle = R() < .5 ? '#437335' : '#548a43'; const s = rnd(2, 7); g.fillRect(R() * 256, R() * 256, s, s); }
  g.strokeStyle = '#3a6a2e'; g.lineWidth = 1;
  for (let i = 0; i < 140; i++) { const x = R() * 254 + 1, y = R() * 250 + 3; g.beginPath(); g.moveTo(x, y); g.lineTo(x + rnd(-2, 2), y - rnd(3, 6)); g.stroke(); }
  grass = ctx.createPattern(c, 'repeat');
}
function makeMiniBg() {
  miniBg = document.createElement('canvas'); miniBg.width = miniBg.height = 208; const g = miniBg.getContext('2d');
  g.fillStyle = '#2f5a2a'; g.fillRect(0, 0, 208, 208);
  const k = 208 / W;
  for (const b of buildings) { g.fillStyle = '#c9b48a'; g.fillRect(b.x * k, b.y * k, Math.max(4, b.w * k), Math.max(4, b.h * k)); }
}

function drawGun(e) {
  const w = curW(e); if (!w) return;
  ctx.fillStyle = '#263238'; ctx.fillRect(8, -3, w.len, 5);
  ctx.fillStyle = w.col; ctx.fillRect(8, -2, Math.min(10, w.len), 3);
}
function drawEnt(e) {
  if (!e.alive) return;
  ctx.save(); ctx.translate(e.x, e.y);
  ctx.fillStyle = '#0004'; ctx.beginPath(); ctx.ellipse(2, 4, 15, 12, 0, 0, TAU); ctx.fill();
  ctx.rotate(e.ang);
  drawGun(e);
  ctx.fillStyle = e.isPlayer ? '#2ec4b6' : 'hsl(' + e.hue + ',58%,46%)';
  ctx.strokeStyle = e.isPlayer ? '#e0fffb' : '#1a1a1a'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(0, 0, e.r, 0, TAU); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#f1c9a0'; ctx.beginPath(); ctx.arc(-1, 0, 7, 0, TAU); ctx.fill();
  ctx.fillStyle = e.armor > 0 ? '#4aa3ff' : '#37474f'; ctx.beginPath(); ctx.arc(-2, 0, 7, Math.PI * .6, Math.PI * 1.4, true); ctx.fill();
  ctx.fillStyle = '#f1c9a0'; ctx.beginPath(); ctx.arc(9, -7, 3.5, 0, TAU); ctx.arc(14, 6, 3.5, 0, TAU); ctx.fill();
  if (e.flash > 0) { ctx.fillStyle = '#ffeb3b'; ctx.beginPath(); const l = (curW(e) ? curW(e).len : 14) + 8; ctx.moveTo(l, 0); ctx.lineTo(l + 14, -5); ctx.lineTo(l + 14, 5); ctx.fill(); }
  ctx.restore();
  // نام اور صحت
  if (!e.isPlayer) {
    ctx.font = 'bold 11px "Noto Naskh Arabic",sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 3;
    ctx.strokeText(e.name, e.x, e.y - 28); ctx.fillText(e.name, e.x, e.y - 28);
  }
  if (e.hp < 100) { ctx.fillStyle = '#0009'; ctx.fillRect(e.x - 16, e.y - 24, 32, 4); ctx.fillStyle = e.hp > 40 ? '#41d36b' : '#ff5252'; ctx.fillRect(e.x - 16, e.y - 24, 32 * clamp(e.hp / 100, 0, 1), 4); }
}
function drawLootItem(it, near) {
  const x = it.x, y = it.y, w = WEAP[it.t];
  ctx.save(); ctx.translate(x, y);
  if (w) {
    ctx.fillStyle = w.col + '55'; ctx.beginPath(); ctx.arc(0, 0, 15, 0, TAU); ctx.fill();
    ctx.fillStyle = '#263238'; ctx.fillRect(-w.len / 2 - 1, -3, w.len + 2, 6); ctx.fillStyle = w.col; ctx.fillRect(-w.len / 2, -2, w.len, 4);
    ctx.fillStyle = '#263238'; ctx.fillRect(-4, 2, 5, 7);
  } else if (it.t.startsWith('ammo')) {
    ctx.fillStyle = '#37474f'; ctx.fillRect(-9, -7, 18, 14); ctx.fillStyle = ITEMC[it.t];
    for (let i = -1; i <= 1; i++) ctx.fillRect(i * 5 - 1.5, -5, 3, 10);
  } else if (it.t === 'med' || it.t === 'band') {
    const s = it.t === 'med' ? 10 : 7; ctx.fillStyle = '#fff'; ctx.fillRect(-s, -s, s * 2, s * 2);
    ctx.fillStyle = '#e53935'; ctx.fillRect(-s * .7, -s * .2, s * 1.4, s * .4); ctx.fillRect(-s * .2, -s * .7, s * .4, s * 1.4);
  } else if (it.t.startsWith('armor')) {
    ctx.fillStyle = ITEMC[it.t]; ctx.strokeStyle = '#0d2a4d'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(-9, -8); ctx.lineTo(9, -8); ctx.lineTo(8, 4); ctx.lineTo(0, 11); ctx.lineTo(-8, 4); ctx.closePath(); ctx.fill(); ctx.stroke();
  } else if (it.t === 'gren') {
    ctx.fillStyle = '#2e7d32'; ctx.beginPath(); ctx.arc(0, 1, 8, 0, TAU); ctx.fill(); ctx.fillStyle = '#bdbdbd'; ctx.fillRect(-2, -10, 4, 5);
  }
  ctx.restore();
  if (near) {
    ctx.font = 'bold 11px "Noto Naskh Arabic",sans-serif'; ctx.textAlign = 'center'; ctx.fillStyle = '#fff'; ctx.strokeStyle = '#000'; ctx.lineWidth = 3;
    const s = w ? w.n : ITEMN[it.t]; ctx.strokeText(s, x, y - 18); ctx.fillText(s, x, y - 18);
  }
}

function render() {
  if (!G) { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = '#0b1411'; ctx.fillRect(0, 0, cv.width, cv.height); return; }
  if (!grass) makeGrass();
  const p = G.player;
  camX += (p.x - camX) * .2; camY += (p.y - camY) * .2;
  const ss = G.shake > 0 ? 4 * G.shake / .15 : 0;
  const ox = camX + (R() - .5) * ss, oy = camY + (R() - .5) * ss;
  const k = dpr * sc, vwW = vw / sc, vhW = vh / sc;
  const x0 = ox - vwW / 2, y0 = oy - vhW / 2, x1 = ox + vwW / 2, y1 = oy + vhW / 2;
  ctx.setTransform(k, 0, 0, k, -x0 * k, -y0 * k);
  ctx.fillStyle = '#0b1411'; ctx.fillRect(x0 - 5, y0 - 5, vwW + 10, vhW + 10);
  ctx.fillStyle = grass; ctx.fillRect(Math.max(0, x0), Math.max(0, y0), Math.min(W, x1) - Math.max(0, x0), Math.min(H, y1) - Math.max(0, y0));
  ctx.strokeStyle = '#ff4d4d'; ctx.lineWidth = 6; ctx.strokeRect(0, 0, W, H);
  // عمارتوں کے فرش
  for (const b of buildings) {
    if (b.x > x1 || b.x + b.w < x0 || b.y > y1 || b.y + b.h < y0) continue;
    ctx.fillStyle = b.fl; ctx.fillRect(b.x, b.y, b.w, b.h);
    ctx.strokeStyle = '#0003'; ctx.lineWidth = 1;
    for (let xx = b.x + 24; xx < b.x + b.w; xx += 24) { ctx.beginPath(); ctx.moveTo(xx, b.y); ctx.lineTo(xx, b.y + b.h); ctx.stroke(); }
  }
  // لوٹ
  for (const it of G.loot) {
    if (it.x < x0 - 20 || it.x > x1 + 20 || it.y < y0 - 20 || it.y > y1 + 20) continue;
    drawLootItem(it, Math.hypot(it.x - p.x, it.y - p.y) < 70);
  }
  // رکاوٹیں: ڈبے، دیواریں، پتھر
  const trees = [];
  queryObs(x0 - 40, y0 - 40, x1 + 40, y1 + 40, o => {
    if (o.k === 1) {
      if (o.crate) { ctx.fillStyle = '#8d6e3f'; ctx.fillRect(o.x0, o.y0, o.x1 - o.x0, o.y1 - o.y0); ctx.strokeStyle = '#4e3b1c'; ctx.lineWidth = 2; ctx.strokeRect(o.x0 + 1, o.y0 + 1, o.x1 - o.x0 - 2, o.y1 - o.y0 - 2); }
      else { ctx.fillStyle = '#3b3f44'; ctx.fillRect(o.x0, o.y0, o.x1 - o.x0, o.y1 - o.y0); ctx.strokeStyle = '#8a9099'; ctx.lineWidth = 1.5; ctx.strokeRect(o.x0 + .5, o.y0 + .5, o.x1 - o.x0 - 1, o.y1 - o.y0 - 1); }
    } else if (o.rock) {
      ctx.fillStyle = '#0003'; ctx.beginPath(); ctx.arc(o.x + 3, o.y + 4, o.r, 0, TAU); ctx.fill();
      ctx.fillStyle = '#7d8388'; ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, TAU); ctx.fill();
      ctx.fillStyle = '#a2a8ad'; ctx.beginPath(); ctx.arc(o.x - o.r * .25, o.y - o.r * .25, o.r * .55, 0, TAU); ctx.fill();
    } else trees.push(o);
  });
  for (const o of trees) {
    ctx.fillStyle = '#0003'; ctx.beginPath(); ctx.arc(o.x + 4, o.y + 5, o.r, 0, TAU); ctx.fill();
    ctx.fillStyle = '#2d5a22'; ctx.beginPath(); ctx.arc(o.x, o.y, o.r, 0, TAU); ctx.fill();
    ctx.fillStyle = '#3f7a30'; ctx.beginPath(); ctx.arc(o.x - o.r * .2, o.y - o.r * .2, o.r * .65, 0, TAU); ctx.fill();
    ctx.fillStyle = '#4f9140'; ctx.beginPath(); ctx.arc(o.x - o.r * .35, o.y - o.r * .35, o.r * .3, 0, TAU); ctx.fill();
  }
  // مردہ نشان
  for (const e of G.ents) if (!e.alive) { ctx.fillStyle = '#0006'; ctx.beginPath(); ctx.arc(e.x, e.y, 11, 0, TAU); ctx.fill(); }
  // بم
  for (const g of G.grens) { ctx.fillStyle = '#2e7d32'; ctx.beginPath(); ctx.arc(g.x, g.y, 6, 0, TAU); ctx.fill(); if (((g.t * 6) | 0) % 2) { ctx.strokeStyle = '#ff5252'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(g.x, g.y, 9, 0, TAU); ctx.stroke(); } }
  for (const e of G.ents) if (e !== p) drawEnt(e);
  drawEnt(p);
  if (p.alive) { ctx.strokeStyle = '#ffffff55'; ctx.lineWidth = 1; ctx.setLineDash([4, 6]); ctx.beginPath(); ctx.moveTo(p.x + Math.cos(p.ang) * 30, p.y + Math.sin(p.ang) * 30); ctx.lineTo(p.x + Math.cos(p.ang) * 150, p.y + Math.sin(p.ang) * 150); ctx.stroke(); ctx.setLineDash([]); }
  // گولیاں
  ctx.lineCap = 'round';
  for (const b of G.bullets) { ctx.strokeStyle = '#fff59d'; ctx.lineWidth = 2.5; const l = Math.hypot(b.vx, b.vy) * .035; ctx.beginPath(); ctx.moveTo(b.x, b.y); ctx.lineTo(b.x - b.vx / Math.hypot(b.vx, b.vy) * l, b.y - b.vy / Math.hypot(b.vx, b.vy) * l); ctx.stroke(); }
  ctx.lineCap = 'butt';
  // اثرات
  for (const f of G.fx) {
    const a = 1 - f.t / .5;
    if (f.type === 'boom') { ctx.fillStyle = f.c; ctx.globalAlpha = a * .6; ctx.beginPath(); ctx.arc(f.x, f.y, f.r * (1 - a * .8 + .2), 0, TAU); ctx.fill(); ctx.globalAlpha = 1; }
    else { ctx.fillStyle = f.c; ctx.globalAlpha = a; ctx.beginPath(); ctx.arc(f.x, f.y, 3 + f.t * 10, 0, TAU); ctx.fill(); ctx.globalAlpha = 1; }
  }
  // نقصان کے اعداد
  ctx.font = 'bold 14px "Noto Naskh Arabic",sans-serif'; ctx.textAlign = 'center';
  for (const t of G.texts) { ctx.globalAlpha = 1 - t.t / .9; ctx.fillStyle = t.col; ctx.strokeStyle = '#000'; ctx.lineWidth = 3; ctx.strokeText(t.s, t.x, t.y); ctx.fillText(t.s, t.x, t.y); }
  ctx.globalAlpha = 1;
  // زون: باہر سرخ، حد کی لکیر، اگلا زون سفید
  const z = G.zone;
  ctx.fillStyle = 'rgba(255,40,40,.22)'; ctx.beginPath(); ctx.rect(x0 - 10, y0 - 10, vwW + 20, vhW + 20); ctx.arc(z.x, z.y, z.r, 0, TAU, true); ctx.fill('evenodd');
  ctx.strokeStyle = '#4aa3ff'; ctx.lineWidth = 5; ctx.beginPath(); ctx.arc(z.x, z.y, z.r, 0, TAU); ctx.stroke();
  if (!z.final && z.state === 'wait') { ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.setLineDash([16, 12]); ctx.beginPath(); ctx.arc(z.tx, z.ty, z.tr, 0, TAU); ctx.stroke(); ctx.setLineDash([]); }
  renderMini();
}
function renderMini() {
  if (!miniBg) makeMiniBg();
  const z = G.zone, p = G.player, s = 208 / W;
  mctx.drawImage(miniBg, 0, 0);
  mctx.fillStyle = 'rgba(255,40,40,.35)'; mctx.beginPath(); mctx.rect(0, 0, 208, 208); mctx.arc(z.x * s, z.y * s, z.r * s, 0, TAU, true); mctx.fill('evenodd');
  mctx.strokeStyle = '#4aa3ff'; mctx.lineWidth = 2; mctx.beginPath(); mctx.arc(z.x * s, z.y * s, z.r * s, 0, TAU); mctx.stroke();
  if (!z.final) { mctx.strokeStyle = '#fff'; mctx.lineWidth = 2; mctx.beginPath(); mctx.arc(z.tx * s, z.ty * s, z.tr * s, 0, TAU); mctx.stroke(); }
  mctx.fillStyle = p.alive ? '#2ee6d0' : '#888'; mctx.strokeStyle = '#000'; mctx.lineWidth = 2;
  mctx.beginPath(); mctx.arc(p.x * s, p.y * s, 6, 0, TAU); mctx.fill(); mctx.stroke();
}
