'use strict';
// ===== بوٹس کی عقل =====
function usable(e, s) { return s && (s.mag > 0 || e.ammo[WEAP[s.w].ammo] > 0); }
function hasUsable(e) { return usable(e, e.slots[0]) || usable(e, e.slots[1]); }
function chooseWeapon(b) {
  let bi = -1, bv = -1;
  for (let i = 0; i < 2; i++) { const s = b.slots[i]; if (usable(b, s) && WEAP[s.w].val > bv) { bv = WEAP[s.w].val; bi = i; } }
  if (bi >= 0 && bi !== b.cur && b.fireCd <= 0) switchSlot(b, bi);
}
function randGoalInZone(z) {
  for (let i = 0; i < 20; i++) {
    const a = R() * TAU, d = Math.sqrt(R()) * z.tr * .85;
    const x = clamp(z.tx + Math.cos(a) * d, 60, W - 60), y = clamp(z.ty + Math.sin(a) * d, 60, H - 60);
    if (!blockedPt(x, y, 20)) return { x, y };
  }
  return { x: z.tx, y: z.ty };
}
// عمارت کے دروازے سے گزر کر منزل تک
function navTarget(b, gx, gy) {
  const bg = inB(gx, gy, 0), bb = inB(b.x, b.y, 0);
  if (bg === bb) { b.nav = null; return [gx, gy]; }
  if (!b.nav || b.nav.g !== bg || b.nav.b !== bb) {
    const bd = bb || bg; let bestD = null, bs = 1e9;
    for (const d of bd.doors) { const s = bb ? Math.hypot(d.ox - gx, d.oy - gy) : Math.hypot(d.ox - b.x, d.oy - b.y); if (s < bs) { bs = s; bestD = d; } }
    b.nav = { g: bg, b: bb, d: bestD, st: 0 };
  }
  const n = b.nav, d = n.d;
  if (bb) { // باہر نکلنا
    if (n.st === 0) { if (Math.hypot(b.x - d.ix, b.y - d.iy) < 26) n.st = 1; return [d.ix, d.iy]; }
    return [d.ox, d.oy];
  }
  if (n.st === 0) { if (Math.hypot(b.x - d.ox, b.y - d.oy) < 26) n.st = 1; return [d.ox, d.oy]; }
  return [d.ix, d.iy];
}
function botDecide(b) {
  const D = DIFFS[G.diff], z = G.zone;
  let en = null, ed = 1e9;
  for (const o of G.ents) {
    if (o === b || !o.alive) continue;
    const d = Math.hypot(o.x - b.x, o.y - b.y);
    if (d < ed && d < 440 && rayObs(b.x, b.y, o.x, o.y) >= 1) { en = o; ed = d; }
  }
  const canShoot = hasUsable(b);
  if (en && b.enemy !== en) { b.react = D.react * (.7 + R() * .6); b.engage = R() < b.aggr; }
  // جو بوٹ لڑنا نہیں چاہتا وہ تب ہی لڑے گا جب اس پر حملہ ہو
  const attacked = G.t - b.hitT < 3 && b.hitBy === en;
  if (en && !canShoot && ed > 260) en = null;
  else if (en && canShoot && !attacked && (!b.engage || G.t < 30 || ed > 110 + b.aggr * 170)) en = null;
  b.enemy = en; b.ed = ed;
  chooseWeapon(b);
  const outNow = Math.hypot(b.x - z.x, b.y - z.y) > z.r - 25;
  const outNext = Math.hypot(b.x - z.tx, b.y - z.ty) > z.tr - 70 && !z.final;
  const urgent = outNow || (outNext && (z.state === 'shrink' || z.t < 12));
  if (urgent) b.mode = 'zone';
  else if (en && canShoot) b.mode = 'fight';
  else if (en) b.mode = 'flee';
  else if (b.hp < 55 && (b.band || b.med) && b.healT <= 0) { b.mode = 'heal'; startHeal(b, b.hp < 40 && b.med ? 'med' : (b.band ? 'band' : 'med')); }
  else if (b.healT > 0) b.mode = 'heal';
  else {
    if (b.reloadT <= 0 && b.slots[b.cur] && b.slots[b.cur].mag < WEAP[b.slots[b.cur].w].mag * .4) startReload(b);
    let best = null, bd = 700;
    for (const it of G.loot) {
      const d = Math.hypot(it.x - b.x, it.y - b.y);
      if (d < bd && wantItem(b, it)) { bd = d; best = it; }
    }
    if (best) { b.mode = 'loot'; b.goal = { x: best.x, y: best.y }; b.goalT = 8; }
    else {
      b.mode = 'roam';
      if (!b.goal || b.goalT <= 0 || Math.hypot(b.goal.x - b.x, b.goal.y - b.y) < 40) { b.goal = randGoalInZone({ tx: z.x, ty: z.y, tr: z.r * .8 }); b.goalT = 14; }
    }
  }
  if (b.mode === 'zone') {
    if (b.zgPh !== z.phase || !b.zg) { const a = R() * TAU, d = Math.sqrt(R()) * z.tr * .6; b.zg = { x: z.tx + Math.cos(a) * d, y: z.ty + Math.sin(a) * d }; b.zgPh = z.phase; }
    b.goal = b.zg;
  }
  // بم
  if (b.mode === 'fight' && b.gren > 0 && G.diff > 0 && ed > 110 && ed < 320 && R() < .12) throwGren(b, en.x, en.y);
}
function botAI(b, dt) {
  const D = DIFFS[G.diff];
  b.thinkT -= dt; b.goalT -= dt; b.react -= dt; b.strafeT -= dt; b.burstT = (b.burstT || 0) - dt;
  if (b.burstT <= 0) { b.bursting = !b.bursting; b.burstT = b.bursting ? rnd(.5, 1.1) : rnd(.45, 1.0); }
  if (b.thinkT <= 0) { b.thinkT = .2 + R() * .15; botDecide(b); }
  if (b.strafeT <= 0) { b.strafeT = 1 + R() * 1.6; b.strafe = R() < .5 ? -1 : 1; }
  b.fire = false;
  let dx = 0, dy = 0, want = 0;
  const en = b.enemy && b.enemy.alive ? b.enemy : null;
  // رخ اور فائر
  if (en) {
    const sp = curW(b) ? curW(b).spd : 900, tt = b.ed / sp * D.lead;
    const ta = Math.atan2(en.y + en.vy * tt - b.y, en.x + en.vx * tt - b.x);
    const diff = angDiff(b.ang, ta), step = D.turn * dt;
    b.ang += clamp(diff, -step, step);
    const w = curW(b);
    if ((b.mode === 'fight' || b.mode === 'zone') && w && b.react <= 0 && Math.abs(diff) < .16 && b.ed < w.range * .95) b.fire = b.bursting;
  }
  // حرکت
  if (b.mode === 'fight' && en) {
    const w = curW(b), pd = w ? w.range * .45 : 200;
    const ux = (en.x - b.x) / (b.ed || 1), uy = (en.y - b.y) / (b.ed || 1);
    let a = 0; if (b.ed > pd * 1.3) a = 1; else if (b.ed < pd * .6) a = -1;
    dx = ux * a - uy * b.strafe * .8; dy = uy * a + ux * b.strafe * .8; want = 1;
  } else if (b.mode === 'flee' && en) {
    dx = (b.x - en.x); dy = (b.y - en.y); want = 1;
  } else if (b.mode === 'heal') {
    want = 0;
  } else if (b.goal) {
    const [tx, ty] = navTarget(b, b.goal.x, b.goal.y);
    dx = tx - b.x; dy = ty - b.y; want = 1;
    if (b.mode === 'zone' && Math.hypot(b.goal.x - b.x, b.goal.y - b.y) < 40) want = 0;
  }
  const l = Math.hypot(dx, dy);
  if (want && l > 1) { dx /= l; dy /= l; } else { dx = dy = 0; }
  if (!en || b.mode !== 'fight') { if (l > 1 && !en) b.ang += clamp(angDiff(b.ang, Math.atan2(dy, dx)), -D.turn * dt, D.turn * dt); }
  // اٹکنے کا علاج
  b.sT += dt;
  if (b.sT > .7) {
    if (want && Math.hypot(b.x - b.sx, b.y - b.sy) < 9) { b.unT = .8; b.us = R() < .5 ? -1 : 1; if (b.mode === 'roam') b.goalT = 0; }
    b.sx = b.x; b.sy = b.y; b.sT = 0; b.stuckN = (b.stuckN || 0) + (b.unT > 0 ? 1 : 0);
  }
  if (b.unT > 0) { b.unT -= dt; const c = Math.cos(1.3 * b.us), s = Math.sin(1.3 * b.us); const nx = dx * c - dy * s, ny = dx * s + dy * c; dx = nx; dy = ny; }
  b.mx = dx; b.my = dy;
}
