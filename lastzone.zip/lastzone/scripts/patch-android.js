// cap add android کے بعد چلتا ہے: لینڈ اسکیپ، فل اسکرین، آئیکن اور اسپلیش بدلتا ہے
const fs = require('fs');
const path = require('path');
const main = path.join('android', 'app', 'src', 'main');
const res = path.join(main, 'res');

function walk(dir, fn) {
  for (const f of fs.readdirSync(dir)) {
    const p = path.join(dir, f);
    if (fs.statSync(p).isDirectory()) walk(p, fn); else fn(p);
  }
}

// 1) صرف لینڈ اسکیپ
const mf = path.join(main, 'AndroidManifest.xml');
let m = fs.readFileSync(mf, 'utf8');
if (!m.includes('screenOrientation')) m = m.replace('<activity', '<activity android:screenOrientation="sensorLandscape"');
fs.writeFileSync(mf, m);
console.log('manifest ok');

// 2) فل اسکرین (اسٹیٹس بار کے بغیر)
const sf = path.join(res, 'values', 'styles.xml');
let s = fs.readFileSync(sf, 'utf8');
if (!s.includes('windowFullscreen')) {
  s = s.replace(/(<style name="AppTheme\.NoActionBar"[^>]*>)/,
    '$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');
}
fs.writeFileSync(sf, s);
console.log('styles ok');

// 3) آئیکن
const src = 'android-icons';
for (const d of fs.readdirSync(src)) {
  const sd = path.join(src, d);
  if (!fs.statSync(sd).isDirectory()) continue;
  const td = path.join(res, d);
  fs.mkdirSync(td, { recursive: true });
  for (const f of fs.readdirSync(sd)) fs.copyFileSync(path.join(sd, f), path.join(td, f));
}
const bgf = path.join(res, 'values', 'ic_launcher_background.xml');
fs.writeFileSync(bgf, '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#0F2A1D</color>\n</resources>\n');
console.log('icons ok');

// 4) اسپلیش اسکرین: ہر splash.png سادہ تاریک تصویر سے بدل دیں
let n = 0;
walk(res, p => { if (path.basename(p) === 'splash.png') { fs.copyFileSync(path.join(src, 'splash.png'), p); n++; } });
console.log('splash replaced:', n);
